
This directories work in conjunction with Teem's old GNUMakefiles to
store object files, libraries, and executables.  The win32 directory
contains some additional sources and programs that are not actively
supported.

It is now (post Teem-1.9) recommended that Teem be built with Cmake.

At some later release this subdirectory should disappear.
